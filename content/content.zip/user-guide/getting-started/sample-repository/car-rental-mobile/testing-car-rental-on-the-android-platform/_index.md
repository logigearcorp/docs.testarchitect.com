--- 
title: "Testing Car Rental on the Android platform"
linktitle: "Testing Car Rental on the Android platform"
description: "The Car Rental application on the Android platform mimics a reservation system for a fictitious car rental company."
weight: 1
aliases: 
    - /TA_Tutorials_Sample_App/Topics/SR_Car_Rental_Android_def.html
keywords: "Car Rental, Android"
---

The Car Rental application on the Android platform mimics a reservation system for a fictitious car rental company.

Car Rental Android is a Java-based application that runs on Android. The purpose of the application is to demonstrate Android automated testing from a Windows or Linux host.

{{<important>}} Android automation is only supported on Windows.

1.  [Car Rental Android configuration](/user-guide/getting-started/sample-repository/car-rental-mobile/testing-car-rental-on-the-android-platform/car-rental-android-configuration/)  
Before executing sample Car Rental automated tests on an Android device, a series of steps must be performed on both the host machine and the Android device.
2.  [Executing Car Rental tests on Android device](/user-guide/getting-started/sample-repository/car-rental-mobile/testing-car-rental-on-the-android-platform/executing-car-rental-tests-on-android-device)  
The Car Rental automated test modules are part of the TestArchitect test suites provided in the Sample Repository to demonstrate automated testing of the AUT on the Android platform.


