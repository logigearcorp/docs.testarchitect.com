--- 
title: "Mobile testing"
linktitle: "Mobile testing"
description: "This topic lists additional software requirements needed to perform mobile testing."
weight: 4
aliases: 
    - /TA_ReleaseNotes/DITA_source/Software_Requirements_mobile_testing.html
keywords: 
---

This topic lists additional software requirements needed to perform mobile testing.

## iOS testing

-   Xcode installed.
-   Xcode Command Line Tools installed.
-   iTunes installed. Available from: [http://www.apple.com/itunes](http://www.apple.com/itunes)


