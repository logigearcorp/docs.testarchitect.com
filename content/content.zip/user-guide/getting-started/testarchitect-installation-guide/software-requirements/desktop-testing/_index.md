--- 
title: "Desktop testing"
linktitle: "Desktop testing"
description: "This topic describes additional software requirements needed to perform desktop testing."
weight: 2
aliases: 
    - /TA_ReleaseNotes/DITA_source/Software_Requirements_desktop_testing.html
keywords: 
---

This topic describes additional software requirements needed to perform desktop testing.

## .NET and WPF application testing

-   To test .NET and WPF applications, Microsoft .NET Framework ver. 3.5, 4.0, 4.5, or 4.5.1 must be installed on your TestArchitect Controller execution machine\(s\).




