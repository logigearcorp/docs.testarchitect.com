--- 
title: "Enabling breakpoints"
linktitle: "Enabling breakpoints"
description: "Reactivating a disabled breakpoint."
weight: 6
aliases: 
    - /TA_Help/Topics/Debugging_enabling_breakpoints.html
keywords: "debugging, enabling breakpoints, breakpoints, enabling, breakpoints, debugging"
---

Reactivating a disabled breakpoint.

To enable the currently selected disabled breakpoint, follow these steps:

1.  Right-click the row header that contains the disabled breakpoint.

2.  Select **Debug** \> **Enable Breakpoint**.





