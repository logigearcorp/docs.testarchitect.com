--- 
title: "Associating TestArchitect and Team Foundation Server test cases in Visual Studio"
linktitle: "Associating TA and TFS test cases"
description: "To execute TestArchitect test cases from MTM or the Test Hub, an association between TestArchitect tests and Team Foundation Server tests must be created in the related Visual Studio project."
weight: 6
aliases: 
    - /TA_Help/Topics/ug_MTM_associate.html
keywords: "integration, MTM, test association, test association, Microsoft Test Manager"
---

To execute TestArchitect test cases from MTM or the Test Hub, an association between TestArchitect tests and Team Foundation Server tests must be created in the related Visual Studio project.

Ensure that you have already taken the following step\(s\):

-   [Created](/user-guide/integration-with-third-party-tools/tfs-integration/on-premises-tfs-environment-configuration/running-tests-under-on-premises-tfs/creating-ta-tfs-projects) TA-TFS integration project.

Running TA tests from MTM requires two types of associations:

-   the mappings of TA and TFS test cases in the two respective systems, discussed elsewhere; and
-   a process of association in the related Visual Studio project. This process automatically generates C\# code snippets in Microsoft Visual Studio to link the TA and TFS test cases.

1.  Start Visual Studio.

2.  Right-click a project, and then select **Associate**.

    **Fastpath:** Alternatively, click the **Associate** ![](/images/TA_Help/Images/MTM_generate_and_associate_test_method_from_testArchitect_btn.png) button on the Visual Studio toolbar.

    {{<note>}} If the **Associate** button is not visible on the Visual Studio toolbar, enable the button by right-clicking on the toolbar and selecting **TestArchitect** from the context menu.

3.  In the Connect to Team Foundation Server dialog box, select the server to connect to from the **Team Foundation Server** drop-down box, and then choose the correct team project values for **Team Project Collections** and **Team Projects**. Click **Connect** to establish an association between TFS and TestArchitect.

    ![](/images/TA_Help/Images/Connect_to_TFS_from_VS.png)

4.  In the Select Test Plan dialog box, choose a test plan, then click **Select plan** to proceed.

    ![](/images/TA_Help/Images/select_test_plan_VS.png)

5.  In the Associate Tests dialog box, select the test suites and test cases to associate with the tests. Tests which have been associated previously are selected automatically. After you finish selecting the desired tests, click **Associate**.

    ![](/images/TA_Help/Images/VS_select_test_to_associate.png)

    {{<tip>}}

    -   TFS test cases that have not been associated are indicated in GREEN. Whereas, TFS test cases that have been associated are indicated in BLUE. Note that, if you select associated TFS test cases, they will be re-associated.
    -   Filtering TFS test cases:
        -   In the Associate Tests dialog box, you can select the **Filter** button to narrow down the list of test cases displayed based on the selected conditions.

            ![](/images/TA_Help/Images/TFS_association_filters.png)

        -   In the Advanced filter dialog box, by defining one or more clauses, you can filter from work items to return the set of work items that interest you. For more information about query fields, operators, and macros, see [here](https://docs.microsoft.com/en-us/vsts/work/track/query-operators-variables).
        -   To temporarily disable the specified filtering conditions, in the Associate Tests dialog box, clear the check box as follows.

            ![](/images/TA_Help/Images/TA_TFS_association_filtering.png)

        -   To remove totally the specified filtering conditions, in the Associate Tests dialog box, click **X** as follows.

            ![](/images/TA_Help/Images/TA_TFS_association_filtering_remove.png)

    -   If the test association fails due to some reasons, you will see the following error dialog box. Click **View Log File** to troubleshoot, if needed.

        ![](/images/TA_Help/Images/TA_TFS_association_failed.png)

    -   If the test association succeeds, a confirmation dialog box appears.

        ![](/images/TA_Help/Images/TA_MTM_association_dlg.png)

6.  Click **OK** to exit the confirmation dialog box.

    -   Under the **TestArchitect\_Generated** folder, test methods are generated in the project as follows:

        ![](/images/TA_Help/Images/VS_project_after_associate.png)

    -   In MTM, information on the association is added into test cases as follows:

        ![](/images/TA_Help/Images/MTM_association_added_toTC.png)

7.  [Check in](https://docs.microsoft.com/en-us/vsts/tfvc/check-your-work-team-codebase?view=vsts#choose-the-files-you-want-to-check-in) your test method on the TFS server.

    {{<remember>}} For TFS 2017, you are required to explicitly check in the following DLL LogiGear.TestArchitect.TAIntegrationLoader.dll

    ![](/images/TA_Help/Images/check_in_TA_dll.png)


Microsoft Visual Studio automatically generates C\# code snippets which associate the TestArchitect test cases with the TFS test cases. You normally do not need to edit the generated snippets. However, you should verify that the test case IDs for each test method match the associated IDs.

![](/images/TA_Help/Images/MTM_generated_code.png)

In the above example, four C\# test methods have been generated \(one method for each test case\) for the four TestArchitect test cases \(TC01, TC02, TC03, and TC04\). Each method consists of a call to RunTestCase, which starts the execution of the TestArchitect test case whose source field maps to the TFS test cases with identifiers 703, 704, 705, and 706 respectively.

{{<important>}} This task is one that must often be repeated, especially when you have modified mapped TFS test cases. \(For example, you remove or add test cases, or change the order of a test case run.\) When you do so, the association between TFS test cases and Visual Studio test methods/TestArchitect test cases is compromised. Hence, it is necessary that you perform the following steps again:

1.  Re-[associate](/user-guide/integration-with-third-party-tools/tfs-integration/on-premises-tfs-environment-configuration/running-tests-under-on-premises-tfs/associating-ta-and-tfs-test-cases) TestArchitect test cases with TFS test cases.
2.  Check in your project.
3.  [Queue](/user-guide/integration-with-third-party-tools/tfs-integration/on-premises-tfs-environment-configuration/installing-and-configuring-microsoft-components-for-on-premises-tfs/automating-a-test-case-in-mtm/queuing-a-new-build/) the build.




