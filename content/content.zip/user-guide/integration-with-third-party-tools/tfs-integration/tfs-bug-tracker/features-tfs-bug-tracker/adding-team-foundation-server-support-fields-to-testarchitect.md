--- 
title: "Adding Team Foundation Server - support fields to TestArchitect"
linktitle: "Adding Team Foundation Server - support fields to TestArchitect"
description: "Registered TA bugs, by default, have the fields Summary, Description, Source and Status, all of which can be kept in sync with the associated TFS bug. User-defined fields can be created in TestArchitect to accept values from other fields of a TFS bug."
weight: 4
aliases: 
    - /TA_Help/Topics/Bugs_defined_field_TFS.html
keywords: "TFS, creating custom fields, custom fields, integration, creating custom fields"
---

Registered TA bugs, by default, have the fields **Summary**, **Description**, **Source** and **Status**, all of which can be kept in sync with the associated TFS bug. User-defined fields can be created in TestArchitect to accept values from other fields of a TFS bug.

To ensure synchronization between a TFS field and its corresponding TestArchitect user-defined field, ensure that the field's names on both TFS and TestArchitect are identical.

To have user-defined fields in TA bugs that can accept values from TFS, repeat the following steps for each field you wish to create:

1.  In TestArchitect, create a [user-defined field](/administration-guide/user-defined-fields/creating-a-user-defined-field) in TestArchitect with the following properties:

    -   **Name**: Be sure to enter a name which is identical to the existing TFS field, for example Activity.
    -   **Applied To**: Select Bug entity.
    -   **Value Type**: Select Single line text or Multi line text.
2.  Create a [registered bug](/user-guide/integration-with-third-party-tools/tfs-integration/tfs-bug-tracker/configuring-tfs-bug-tracker-integration/creating-registered-ta-bugs-with-tfs-bug-tracker#). Note that the new field appears in it.


The TestArchitect user-defined field loads additional value from TFS field, as depicted below:

![](/images/TA_Help/Images/Bug_user_define_fields_TFS.png)


