--- 
title: "Summary: What you learned"
linktitle: "Summary: What you learned"
description: "What you learned in this lesson: How to create a data set How to run a data-driven test How to create an external data source"
weight: 14
aliases: 
    - /TA_Tutorials/Topics/Summary_Creating_data_driven_tests.html
keywords: 
---

**What you learned in this lesson:**

-   How to create a data set
-   How to run a data-driven test
-   How to create an external data source



