--- 
title: "Summary: What you learned"
linktitle: "Summary: What you learned"
description: "What you learned in this lesson: How to create a working test of an application (AUT) in TestArchitect . How to make use of a TestArchitect interface in your test cases. How to run a test and view its ..."
weight: 4
aliases: 
    - /TA_Tutorials/Topics/Summary_Interfacing_with_a_GUI.html
keywords: 
---

**What you learned in this lesson:**

-   How to create a working test of an application \(AUT\) in TestArchitect.
-   How to make use of a TestArchitect interface in your test cases.
-   How to run a test and view its results.



