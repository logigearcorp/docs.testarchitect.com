--- 
title: "Summary: What you learned"
linktitle: "Summary: What you learned"
description: "What you learned in this lesson: How to read, create and maintain interface entities and interface elements. How to map and maintain interface definitions with the Interface Viewer. How to use your ..."
weight: 6
aliases: 
    - /TA_Tutorials/Topics/Summary_Working_with_interface_definitions.html
keywords: 
---

What you learned in this lesson:

-   How to read, create and maintain interface entities and interface elements.
-   How to map and maintain interface definitions with the Interface Viewer.
-   How to use your interface definitions in a test.


