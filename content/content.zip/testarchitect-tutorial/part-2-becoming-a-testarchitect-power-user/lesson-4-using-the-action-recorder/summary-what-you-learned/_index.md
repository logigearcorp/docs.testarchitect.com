--- 
title: "Summary: What you learned"
linktitle: "Summary: What you learned"
description: "What you learned in this lesson: How to record actions on controls with the Action Recorder. How to record a check action. How the Action Recorder creates new interface definitions when warranted, and ..."
weight: 5
aliases: 
    - /TA_Tutorials/Topics/Summary_Action_Recorder.html
keywords: 
---

**What you learned in this lesson:**

-   How to record actions on controls with the Action Recorder.
-   How to record a check action.
-   How the Action Recorder creates new interface definitions when warranted, and allows you to modify their TA names.



