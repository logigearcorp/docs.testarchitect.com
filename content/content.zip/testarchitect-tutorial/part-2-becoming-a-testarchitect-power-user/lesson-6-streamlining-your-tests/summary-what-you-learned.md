--- 
title: "Summary: What you learned"
linktitle: "Summary: What you learned"
description: "What you learned in this lesson: Incorporating repetitive test logic into loops Creating user-defined actions How to encapsulate a set of action lines into a new user-defined action Optimizing your ..."
weight: 8
aliases: 
    - /TA_Tutorials/Topics/Summary_Building_action_definition.html
keywords: 
---

What you learned in this lesson:

-   Incorporating repetitive test logic into loops
-   Creating user-defined actions
-   How to encapsulate a set of action lines into a new user-defined action
-   Optimizing your use of arguments to maximize the reusability of an action
-   How to return values from a called action


