--- 
title: "Summary: What you have learned"
linktitle: "Summary: What you have learned"
description: "What you learned in this lesson: How to invoke a harness How to develop custom harnesses in Python, Java, and C# How to create a test case and stub action How to script a GUI-interfacing action How to ..."
weight: 6
aliases: 
    - /TA_Tutorials/Topics/Summary_Scripting_in_other_languages.html
keywords: 
---

What you learned in this lesson:

-   How to invoke a harness
-   How to develop custom harnesses in Python, Java, and C\#
-   How to create a test case and stub action
-   How to script a GUI-interfacing action
-   How to execute a test that uses a harness


