--- 
title: "Summary: What you learned"
linktitle: "Summary: What you learned"
description: "What you learned in this lesson: How to create a test module in TestArchitect Client . How to enter an action line with an action in the editor How to execute a test in TestArchitect How to view the ..."
weight: 4
aliases: 
    - /TA_Tutorials/Topics/Summary_Creating_a_simple_test.html
keywords: 
---

What you learned in this lesson:

-   How to create a test module in TestArchitect Client.
-   How to enter an action line with an action in the editor
-   How to execute a test in TestArchitect
-   How to view the test results


