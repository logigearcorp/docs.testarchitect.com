--- 
title: "Troubleshooting the TestArchitect License Server"
linktitle: "Troubleshooting the TestArchitect License Server"
description: "This section describes possible errors that you might encounter with the TestArchitect License Server, their common causes and possible solutions."
weight: 10
aliases: 
    - /TA_Administration/Topics/adm_LS_troubleshooting.html
keywords: 
---

This section describes possible errors that you might encounter with the TestArchitect License Server, their common causes and possible solutions.

1.  [License keys are unable to be verified when a power outage and connection loss occur](/administration-guide/license-server/troubleshooting-the-testarchitect-license-server/license-keys-are-unable-to-be-verified-when-a-power-outage-and-connection-loss-occur)  




