--- 
title: "Features added to TestArchitect License Server 8.3.1"
linktitle: "Features added to TestArchitect License Server 8.3.1"
description: "This topic describes the changes made in TestArchitect License Server version 8.3.1."
weight: 5
aliases: 
    - /TA_ReleaseNotes/DITA_source/Whats_New_LS_8.3.1.html
keywords: "What is new, License Server 8.3.1, what is new"
---

This topic describes the changes made in TestArchitect License Server version 8.3.1.

-   **[What's new in TestArchitect License Server for Windows](/administration-guide/license-server/version-history/features-added-to-testarchitect-license-server-8-3-1/windows)**  
The following new features and improvements are introduced in TestArchitect License Server version 8.3.1 running under Windows.
-   **[What's new in TestArchitect License Server for Linux](/administration-guide/license-server/version-history/features-added-to-testarchitect-license-server-8-3-1/linux)**  
The following new features and improvements are introduced in TestArchitect License Server version 8.3.1 running under Linux.



