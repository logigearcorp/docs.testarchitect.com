--- 
title: "What's new in TestArchitect License Server for Windows"
linktitle: "Windows"
description: "The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Windows."
weight: 1
aliases: 
    - /TA_ReleaseNotes/DITA_source/Whats_New_LS_Windows_8.4.5.html
keywords: "Release Notes 8.4.5, License Server, Windows, What is new, Windows, License Server 8.4.5, License Server 8.4.5, what is new, Windows"
---

The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Windows.

## License Server {{< permerlink >}} {#concept_what_new_8.3_Windows__section_LS} 

Enhancements

-   **New mechanism to pick up license key:** From TestArchitect 8.4 update 5 onward, the License Server always pick up the licenses key which has the longest expiry date.

