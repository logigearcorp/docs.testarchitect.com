--- 
title: "What's new in TestArchitect License Server for Windows"
linktitle: "Windows"
description: "The following new features and improvements are introduced in TestArchitect License Server version 8.3.4 running under Windows."
weight: 1
aliases: 
    - /TA_ReleaseNotes/DITA_source/Whats_New_LS_8.3.4_Windows.html
keywords: "Release Notes 8.3.4, License Server, Windows, What is new, Windows, License Server 8.3.4, License Server 8.3.4, what is new, Windows"
---

The following new features and improvements are introduced in TestArchitect License Server version 8.3.4 running under Windows.

## License Server {{< permerlink >}} {#concept_what_new_8.3_Windows__section_LS} 

Enhancements to existing features

-   Robust recovery ability: The TestArchitect License Server has now significantly improved, so that previous issues, occurring from a sudden server power outage or when the TestArchitect License Sever processes are ended suddenly, become no longer available.

