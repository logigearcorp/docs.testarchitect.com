--- 
title: "What's new in TestArchitect License Server for Linux"
linktitle: "Linux"
description: "The following new features and improvements are introduced in TestArchitect License Server version 8.3.4 running under Linux."
weight: 2
aliases: 
    - /TA_ReleaseNotes/DITA_source/Whats_New_LS_8.3.4_Linux.html
keywords: "Release Notes 8.3.4, License Server, Linux, What is new, Linux, License Server 8.3.4, License Server 8.3.4, what is new, Linux"
---

The following new features and improvements are introduced in TestArchitect License Server version 8.3.4 running under Linux.

## License Server

Enhancements to existing features

-   Robust recovery ability: The TestArchitect License Server has now significantly improved, so that previous issues, occurring from a sudden server power outage or when the TestArchitect License Sever processes are ended suddenly, become no longer available.

