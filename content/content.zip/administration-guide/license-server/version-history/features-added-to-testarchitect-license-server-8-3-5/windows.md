--- 
title: "What's new in TestArchitect License Server for Windows"
linktitle: "Windows"
description: "The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Windows."
weight: 1
aliases: 
    - /TA_ReleaseNotes/DITA_source/Whats_New_LS_Windows_8.3.5.html
keywords: "Release Notes 8.3.5, License Server, Windows, What is new, Windows, License Server 8.3.5, License Server 8.3.5, what is new, Windows"
---

The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Windows.

## License Server {{< permerlink >}} {#concept_what_new_8.3_Windows__section_LS} 

New features

-   Support for the TestArchitect image on Docker: Every licensed machine is now presented by its computer name and IP address followed by session ID.

