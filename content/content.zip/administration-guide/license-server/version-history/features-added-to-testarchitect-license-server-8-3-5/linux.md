--- 
title: "What's new in TestArchitect License Server for Linux"
linktitle: "Linux"
description: "The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Linux."
weight: 2
aliases: 
    - /TA_ReleaseNotes/DITA_source/Whats_New_LS_Linux_8.3.5.html
keywords: "Release Notes 8.3.5, License Server, Linux, What is new, Linux, License Server 8.3.5, License Server 8.3.5, what is new, Linux"
---

The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Linux.

## License Server

New features

-   Support for the TestArchitect image on Docker: Every licensed machine is now presented by its computer name and IP address followed by session ID.

