--- 
title: "What's new in TestArchitect License Server for Linux"
linktitle: "Linux"
description: "The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Linux."
weight: 2
aliases: 
    - /TA_ReleaseNotes/DITA_source/Whats_New_LS_Linux_8.4.4.html
keywords: "Release Notes 8.4.4, License Server, Linux, What is new, Windows, License Server 8.4.4, License Server 8.4.4, what is new, Linux"
---

The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Linux.

## License Server

Enhancements

-   **New mechanism to keep license key:** From TestArchitect 8.4 update 4 onward, the license key in License Server works under a new mechanism, which enables the license key to get over abrupt/ sudden/ unexpected problems such as power outage.

