--- 
title: "Features added to TestArchitect License Server 8.4.4"
linktitle: "Features added to TestArchitect License Server 8.4.4"
description: ""
weight: 2
aliases: 
    - /TA_ReleaseNotes/DITA_source/Whats_New_LS_8.4.4.html
keywords: 
---

-   **[What's new in TestArchitect License Server for Windows](/administration-guide/license-server/version-history/features-added-to-testarchitect-license-server-8-4-4/windows)**  
The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Windows.
-   **[What's new in TestArchitect License Server for Linux](/administration-guide/license-server/version-history/features-added-to-testarchitect-license-server-8-4-4/linux)**  
The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Linux.




