--- 
title: "What's new in TestArchitect License Server for Windows"
linktitle: "Windows"
description: "The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Windows."
weight: 1
aliases: 
    - /TA_ReleaseNotes/DITA_source/Whats_New_LS_Windows_8.4.4.html
keywords: "Release Notes 8.4.4, License Server, Windows, What is new, Windows, License Server 8.4.4, License Server 8.4.4, what is new, Windows"
---

The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Windows.

## License Server {{< permerlink >}} {#Whats_New_LS_Windows_8.4.4__section_LS} 

Enhancements

-   **New mechanism to keep license key:** From TestArchitect 8.4 update 4 onward, the license key in License Server works under a new mechanism, which enables the license key to get over abrupt/ sudden/ unexpected problems such as power outage.

