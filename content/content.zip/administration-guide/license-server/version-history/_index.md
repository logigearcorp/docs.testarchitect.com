--- 
title: "Version history"
linktitle: "Version history"
description: "This topic describes the changes made in previous versions of TestArchitect License Server."
weight: 2
aliases: 
    - /TA_ReleaseNotes/DITA_source/Version_History_LS.html
keywords: 
---

This topic describes the changes made in previous versions of TestArchitect License Server.

1.  [Features added to TestArchitect License Server 8.4.5](/administration-guide/license-server/version-history/features-added-to-testarchitect-license-server-8-4-5/)  

2.  [Features added to TestArchitect License Server 8.4.4](/administration-guide/license-server/version-history/features-added-to-testarchitect-license-server-8-4-4/)  

3.  [Features added to TestArchitect License Server 8.3.5](/administration-guide/license-server/version-history/features-added-to-testarchitect-license-server-8-3-5/)  

4.  [Features added to TestArchitect License Server 8.3.4](/administration-guide/license-server/version-history/features-added-to-testarchitect-license-server-8-3-4/)  
This topic describes the changes made in TestArchitect License Server version 8.3.1.
5.  [Features added to TestArchitect License Server 8.3.1](/administration-guide/license-server/version-history/features-added-to-testarchitect-license-server-8-3-1/)  
This topic describes the changes made in TestArchitect License Server version 8.3.1.




