--- 
title: "What's new in TestArchitect License Server 8.5.1"
linktitle: "What's new in TestArchitect License Server 8.5.1"
description: "Following are the new features and enhancements introduced in the latest version of TestArchitect License Server."
weight: 1
aliases: 
    - /TA_ReleaseNotes/DITA_source/Whats_New_LS.html
keywords: "What is new, License Server 8.5.1, what is new"
---

Following are the new features and enhancements introduced in the latest version of TestArchitect License Server.

-   **[What's new in TestArchitect License Server for Windows](/administration-guide/license-server/what-s-new-in-testarchitect-license-server-8-5-1/windows)**  
The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Windows.
-   **[What's new in TestArchitect License Server for Linux](/administration-guide/license-server/what-s-new-in-testarchitect-license-server-8-5-1/linux)**  
The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Linux.



