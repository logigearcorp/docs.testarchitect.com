--- 
title: "What's new in TestArchitect License Server for Windows"
linktitle: "Windows"
description: "The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Windows."
weight: 1
aliases: 
    - /TA_ReleaseNotes/DITA_source/Whats_New_LS_Windows.html
keywords: "Release Notes 8.5.1, License Server, Windows, What is new, Windows, License Server 8.5.1, License Server 8.5.1, what is new, Windows"
---

The following new features and improvements are introduced in the latest version of TestArchitect License Server running on Windows.

## License Server {{< permerlink >}} {#concept_what_new_8.3_Windows__section_LS} 

Enhancements

-   [**Annual Subscription**:](/administration-guide/license-server/obtaining-a-testarchitect-license/adding-new-licenses#) TestArchitect now uses an annual subscription model. Once a customer purchases an annual subscription, they can use the software and download all software updates released in the next year. The price also includes professional support & maintenance costs. It will provide a more streamlined approach for customers to adopt TestArchitect.

