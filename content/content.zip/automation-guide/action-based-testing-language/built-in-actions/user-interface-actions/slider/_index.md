--- 
title: "Slider"
linktitle: "Slider"
description: "Actions which interact with a slider control in the AUT."
weight: 8
aliases: 
    - /TA_Automation/Topics/bia_Slider.html
keywords: 
---

Actions which interact with a slider control in the AUT.

1.  [check trackbar value](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/slider/check-trackbar-value)  

2.  [get trackbar value](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/slider/get-trackbar-value)  

3.  [set trackbar value](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/slider/set-trackbar-value)  





