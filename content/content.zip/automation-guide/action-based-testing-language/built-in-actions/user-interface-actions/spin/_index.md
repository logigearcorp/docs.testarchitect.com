--- 
title: "Spin"
linktitle: "Spin"
description: "Actions which interact with spin box control in an AUT."
weight: 9
aliases: 
    - /TA_Automation/Topics/bia_Spinner.html
keywords: 
---

Actions which interact with spin box control in an AUT.

1.  [spin down](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/spin/spin-down)  

2.  [spin up](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/spin/spin-up)  





