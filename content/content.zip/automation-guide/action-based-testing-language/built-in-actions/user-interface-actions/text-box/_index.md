--- 
title: "Text Box"
linktitle: "Text Box"
description: "Actions which interact with text box controls in an AUT."
weight: 14
aliases: 
    - /TA_Automation/Topics/bia_Text_box.html
keywords: 
---

Actions which interact with text box controls in an AUT.

1.  [check pattern in text](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/text-box/check-pattern-in-text)  

2.  [check pattern not in text](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/text-box/check-pattern-not-in-text)  

3.  [check text line](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/text-box/check-text-line)  

4.  [get text line](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/text-box/get-text-line)  





