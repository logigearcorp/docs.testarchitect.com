--- 
title: "Stepper"
linktitle: "Stepper"
description: "Actions which interact with a stepper control of applications running on mobile operating systems."
weight: 11
aliases: 
    - /TA_Automation/Topics/bia_Stepper.html
keywords: 
---

Actions which interact with a stepper control of applications running on mobile operating systems.

-   **[tap stepper button](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/stepper/tap-stepper-button)**  





