--- 
title: "click list item"
linktitle: "click list item"
description: "Description Click an item in a list control. Arguments window TA name of the window. list TA name of the list control. item The item to click, as specified by its text content or index value . ..."
weight: 13
aliases: 
    - /TA_Automation/Topics/bia_click_list_item.html
keywords: "built-in actions, click list item, click list item (action), iOS (action), click list item, Safari, iOS (action), iOS, Safari (action), Android (action), Android, Google Chrome (action), Google Chrome, Android (action), Safari, macOS (action), macOS, Safari (action), click specified item in list box, click specified item in list view"
---

## Description

Click an item in a list control.

## Arguments

-   **window**

    TA name of the window.

-   **list**

    TA name of the list control.

-   **item**

    The item to click, as specified by its text contentor index value.

    {{<important>}} For the list view control only, in order to click an item, enter the aggregated values of every cell value with vertical bars \( \| \) as delimiters.

-   **x**

    \(Optional\) Horizontal position of effective click, specified as distance in pixels from left edge of item . \(Defaults to horizontal center of the item.\)

-   **y**

    \(Optional\) Vertical position of effective click, specified as distance in pixels from top edge of item. \(Defaults to vertical center of the item.\)


## Valid contexts

This action may be used within the following project items:test modules and user-defined actions.

## Notes

-   Built-in UI actions applied to iOS devices specify screen coordinates in points rather than pixels. \(For further details, refer to the built-in action [get screen resolution](/automation-guide/action-based-testing-language/built-in-actions/system-actions/operating-system/get-screen-resolution#li.ios.get_screen_resolution).\)
-   item argument:
    -   The item argumentmay be specified by either of two means:the displayed text of the item, or its numerical index. \(Indexes are one-based; that is, numbering begins at 1.\)
    -   Enclose a numerical text string in quotation marks to differentiate it from a numerical index value. For example, if a text value of an item in a control has a value of 12, you should reference that item by passing 12 surrounded by quotation marks \(that is, "12"\) instead of the numerical 12. Passing the numerical 12 is treated as a reference to an item with an index of **12**, rather than an item holding a text string value of 12.
    -   For list view controls only, to specify an item argument by its text content, enter the combined values of every cell, from left to right, with vertical bars \( \| \) as delimiters.
-   x and yare unsupported arguments and hence invisible. To use them, you must specify both their values and the headers x and y, respectively, in the cells to the right of the last visible argument.
-   This action supports the [<ignore\>](/automation-guide/action-based-testing-language/the-test-language/ignoring-actions) modifier. If the string `<ignore>` is present as the value of any of the arguments, or any argument contains an expression that evaluates to `<ignore>`, the action is skipped during execution.

## Applicable Built-In Settings

The following settings are applicable to this action:[case sensitive](/automation-guide/action-based-testing-language/built-in-settings/value-settings/case-sensitive), [remove double quotes from cells](/automation-guide/action-based-testing-language/built-in-settings/value-settings/remove-double-quotes-from-cells), [standard ASCII only](/automation-guide/action-based-testing-language/built-in-settings/value-settings/standard-ascii-only), [item wait](/automation-guide/action-based-testing-language/built-in-settings/timing-settings/item-wait), [page wait](/automation-guide/action-based-testing-language/built-in-settings/timing-settings/page-wait), [object wait](/automation-guide/action-based-testing-language/built-in-settings/timing-settings/object-wait), [window wait](/automation-guide/action-based-testing-language/built-in-settings/timing-settings/window-wait).

## Applicable Controls

This action is applicable to the following controls:list box, list view.

## Example - Case 1: Use text value to click a list box item

![](/images/TA_Automation/Images/bia_click_list_item_aut.png)

Action Lines

![](/images/TA_Automation/Images/bia_click_list_item_pgm.png)

Result

![](/images/TA_Automation/Images/bia_click_list_item_res.png)

## Example - Case 2: Use numerical index value to click a list box item

![](/images/TA_Automation/Images/bia_click_list_item_index_aut.png)

Action Lines

![](/images/TA_Automation/Images/bia_click_list_item_index_pgm.png)

Result

![](/images/TA_Automation/Images/bia_click_list_item_index_res.png)

## Example - Case 3: Use text value to click a list view item

![](/images/TA_Automation/Images/bia_click_list_item_aut_3.png)

Action Lines

![](/images/TA_Automation/Images/bia_click_list_item_pgm_3.png)

Result

![](/images/TA_Automation/Images/bia_click_list_item_res_3.png)

**Related information**  


[check selected items](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/list-table-grid/check-selected-items)

[get selected items](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/list-table-grid/get-selected-items)
