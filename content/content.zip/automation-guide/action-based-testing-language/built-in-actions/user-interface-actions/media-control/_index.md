--- 
title: "Media control"
linktitle: "Media control"
description: "The Media control actions include built-in actions which interact with the audio or video controls."
weight: 4
aliases: 
    - /TA_Automation/Topics/bia_media_control.html
keywords: 
---

The Media control actions include built-in actions which interact with the audio or video controls.

1.  [pause](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/media-control/pause)  

2.  [play](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/media-control/play)  

3.  [set media property](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/media-control/set-media-property)  

4.  [set volume](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/media-control/set-volume)  





