--- 
title: "Status bar"
linktitle: "Status bar"
description: "Actions which interact with the status bar control in an AUT."
weight: 10
aliases: 
    - /TA_Automation/Topics/bia_Status_Bar.html
keywords: 
---

Actions which interact with the status bar control in an AUT.

1.  [check status bar section state](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/status-bar/check-status-bar-section-state)  

2.  [check status bar section value](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/status-bar/check-status-bar-section-value)  

3.  [get status bar section state](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/status-bar/get-status-bar-section-state)  

4.  [get status bar section value](/automation-guide/action-based-testing-language/built-in-actions/user-interface-actions/status-bar/get-status-bar-section-value)  





