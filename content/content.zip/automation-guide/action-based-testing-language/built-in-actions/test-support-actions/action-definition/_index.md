--- 
title: "Action Definition"
linktitle: "Action Definition"
description: "Action Definition built-in actions help you to define arguments in user-defined actions."
weight: 1
aliases: 
    - /TA_Automation/Topics/bia_Action_definition.html
keywords: 
---

Action Definition built-in actions help you to define arguments in user-defined actions.

1.  [argument](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/action-definition/argument)  




