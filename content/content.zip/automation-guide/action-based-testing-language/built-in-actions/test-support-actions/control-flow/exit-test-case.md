--- 
title: "exit test case"
linktitle: "exit test case"
description: "Description Exit the current test case (skip all remaining action lines in the current test case), and then continue with the next test case. Arguments exit status (Optional) Determine whether the ..."
weight: 8
aliases: 
    - /TA_Automation/Topics/bia_exit_test_case.html
keywords: "built-in actions, exit test case, exit test case (action), exit test case, stop test case, terminate test case, test case termination"
---

## Description

Exit the current test case \(skip all remaining action lines in the current test case\), and then continue with the next test case.

## Arguments {{< permerlink >}} {#bia_exit_test_case__section_arguments} 

-   **exit status**

    \(Optional\) Determine whether the overall final result status must be [Not Finished](/user-guide/working-with-test-results/overview/test-result-status) or not. \(See Notes below.\)

    Possible values:

    -   complete: The operation is successful.
    -   incomplete: \(Default\) The operation is unsuccessful.

## Valid contexts

This action may be used within the following project items:test modules and user-defined actions.

## Notes

-   This action can be used to handle an error situation.

-   This action will exit from the `INITIAL` and `FINAL` sections of a test module, as well as from test cases.
-   When invoked from within a user-defined action, the calling test case is exited.
-   exit status argument:

    -   This argument applies to TestArchitect [8.3 Update 5](/user-guide/version-history/features-added-to-testarchitect-8-3-update-5/) and higher.
    |Status|Description|
    |------|-----------|
    |Incomplete|\(Default\) The overall status of test results is always [Not Finished](/user-guide/working-with-test-results/overview/test-result-status).|
    |Complete|The overall status of test results is not necessarily [Not Finished](/user-guide/working-with-test-results/overview/test-result-status).|


## Applicable Built-In Settings

The following settings are applicable to this action:none.

## Example - Case 1: Exit status is Incomplete

Action Lines

![](/images/TA_Automation/Images/bia_exit_test_case_pgm.png)

Result

When exit test case with the value of Incomplete is executed, the overall status of this test result is Not Finished.

![](/images/TA_Automation/Images/bia_exit_test_case_res_exit_status_incomplete.png)

## Example - Case 2: Exit status is Complete

Action Lines

![](/images/TA_Automation/Images/bia_exit_test_case_complete_pgm.png)

Result

When exit test case with the value of Complete is executed, the overall status of this result is by definition Not Finished. Inf act, in this example, the status is Passed, because checkpoints are successful.

![](/images/TA_Automation/Images/bia_exit_test_case_res_exit_status_complete.png)



