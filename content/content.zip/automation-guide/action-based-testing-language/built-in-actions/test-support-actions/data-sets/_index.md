--- 
title: "Data sets"
linktitle: "Data sets"
description: "Data set built-in actions help you to define and use data sets and filters."
weight: 3
aliases: 
    - /TA_Automation/Topics/bia_Data_set.html
keywords: 
---

Data set built-in actions help you to define and use data sets and filters.

1.  [add data set column](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/data-sets/add-data-set-column)  

2.  [check in data set](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/data-sets/check-in-data-set)  

3.  [create data set](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/data-sets/create-data-set)  

4.  [end create data set](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/data-sets/end-create-data-set)  

5.  [filter](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/data-sets/filter)  

6.  [refill data set](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/data-sets/refill-data-set)  

7.  [repeat for data set](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/data-sets/repeat-for-data-set)  

8.  [row](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/data-sets/row)  

9.  [set data set value](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/data-sets/set-data-set-value)  

10. [use data set](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/data-sets/use-data-set)  

11. [use filter](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/data-sets/use-filter)  





