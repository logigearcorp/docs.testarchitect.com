--- 
title: "status"
linktitle: "status"
description: "Description Keyword to document the status of a test module. Valid contexts This action may be used within the following project items: test modules and user-defined actions. Notes This action has ..."
weight: 9
aliases: 
    - /TA_Automation/Topics/bia_status.html
keywords: "built-in actions, status, status (action)"
---

## Description

Keyword to document the status of a test module.

## Valid contexts

This action may be used within the following project items:test modules and user-defined actions.

## Notes

-   This action has been deprecated in TestArchitect 7.




