--- 
title: "test module"
linktitle: "test module"
description: "Description Keyword to name a test module. Valid contexts This action may be used within the following project items: test modules and user-defined actions. Notes This action has been deprecated in ..."
weight: 10
aliases: 
    - /TA_Automation/Topics/bia_test_module.html
keywords: "built-in actions, test module, test module (action)"
---

## Description

Keyword to name a test module.

## Valid contexts

This action may be used within the following project items:test modules and user-defined actions.

## Notes

-   This action has been deprecated in TestArchitect 7.




