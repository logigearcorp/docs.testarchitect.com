--- 
title: "Deprecated"
linktitle: "Deprecated"
description: "Deprecated built-in actions include those actions which should be avoided, typically because they have been superseded."
weight: 4
aliases: 
    - /TA_Automation/Topics/bia_Deprecated.html
keywords: 
---

Deprecated built-in actions include those actions which should be avoided, typically because they have been superseded.

1.  [author](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/author)  

2.  [check row item](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/check-row-item)  

3.  [date](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/date)  

4.  [last update date](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/last-update-date)  

5.  [last updated by](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/last-updated-by)  

6.  [priority](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/priority)  

7.  [remark](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/remark)  

8.  [sheet](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/sheet)  

9.  [status](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/status)  

10. [test module](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/test-module)  

11. [version](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/version)  

12. [interface frame](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/interface-frame)  

13. [end interface frame](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/end-interface-frame)  

14. [interface element setting](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/interface-element-setting)  

15. [action definition](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/action-definition)  

16. [end action definition](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/end-action-definition)  

17. [assign entity setting](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/assign-entity-setting)  

18. [interface element class](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/interface-element-class)  

19. [interface element class action](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/deprecated/interface-element-class-action)  





