--- 
title: "priority"
linktitle: "priority"
description: "Description Keyword to document the priority of test module. Valid contexts This action may be used within the following project items: test modules and user-defined actions. Notes Insert priority ..."
weight: 6
aliases: 
    - /TA_Automation/Topics/bia_priority.html
keywords: "built-in actions, priority, priority (action)"
---

## Description

Keyword to document the priority of test module.

## Valid contexts

This action may be used within the following project items:test modules and user-defined actions.

## Notes

-   Insert priority into second column. Acceptable values
    -   High
    -   Medium
    -   Low
-   This action has been deprecated in TestArchitect 7.




