--- 
title: "version"
linktitle: "version"
description: "Description Keyword to document the test module version. Valid contexts This action may be used within the following project items: test modules and user-defined actions. Notes This action has been ..."
weight: 11
aliases: 
    - /TA_Automation/Topics/bia_version.html
keywords: "built-in actions, version, version (action)"
---

## Description

Keyword to document the test module version.

## Valid contexts

This action may be used within the following project items:test modules and user-defined actions.

## Notes

-   This action has been deprecated in TestArchitect 7.




