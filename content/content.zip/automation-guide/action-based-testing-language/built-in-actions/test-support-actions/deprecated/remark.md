--- 
title: "remark"
linktitle: "remark"
description: "Description Keyword to note start of user's comments; ignored by the system. Valid contexts This action may be used within the following project items: test modules and user-defined actions. Notes ..."
weight: 7
aliases: 
    - /TA_Automation/Topics/bia_remark.html
keywords: "built-in actions, remark, remark (action)"
---

## Description

Keyword to note start of user's comments; ignored by the system.

## Valid contexts

This action may be used within the following project items:test modules and user-defined actions.

## Notes

-   This action has been deprecated in TestArchitect 7.




