--- 
title: "date"
linktitle: "date"
description: "Description Keyword to document the last update date for the test module. Valid contexts This action may be used within the following project items: test modules and user-defined actions. Notes Insert ..."
weight: 3
aliases: 
    - /TA_Automation/Topics/bia_date.html
keywords: "built-in actions, date, date (action)"
---

## Description

Keyword to document the last update date for the test module.

## Valid contexts

This action may be used within the following project items:test modules and user-defined actions.

## Notes

-   Insert date in second column.
-   This action has been deprecated in TestArchitect 7.




