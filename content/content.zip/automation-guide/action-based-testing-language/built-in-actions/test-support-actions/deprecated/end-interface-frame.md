--- 
title: "end interface frame"
linktitle: "end interface frame"
description: "Description End of a frame. Arguments There are no arguments for this action. Valid contexts This action may be used within the following project items: test modules and user-defined actions. Notes ..."
weight: 13
aliases: 
    - /TA_Automation/Topics/bia_end_interface_frame.html
keywords: "built-in actions, end interface frame, end interface frame (action)"
---

## Description

End of a frame.

## Arguments

There are no arguments for this action.

## Valid contexts

This action may be used within the following project items:test modules and user-defined actions.

## Notes

-   The following interface elements are siblings of the frame.
-   This action has been deprecated in TestArchitect 7.




