--- 
title: "last updated by"
linktitle: "last updated by"
description: "Description Keyword to document the name of user who made the last update, (that is, the user who made changes and checked in the result). Valid contexts This action may be used within the following ..."
weight: 5
aliases: 
    - /TA_Automation/Topics/bia_last_updated_by.html
keywords: "built-in actions, last updated by, last updated by (action)"
---

## Description

Keyword to document the name of user who made the last update, \(that is, the user who made changes and checked in the result\).

## Valid contexts

This action may be used within the following project items:test modules and user-defined actions.

## Notes

-   This action has been deprecated in TestArchitect 7.




