--- 
title: "Documentary"
linktitle: "Documentary"
description: "Documentary built-in actions perform test documentation and assist in properly organizing your test module, which aids in ensuring conformance to the ABT methodology."
weight: 5
aliases: 
    - /TA_Automation/Topics/bia_Documentary.html
keywords: 
---

Documentary built-in actions perform test documentation and assist in properly organizing your test module, which aids in ensuring conformance to the ABT methodology.

1.  [FINAL](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/documentary/final)  

2.  [INITIAL](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/documentary/initial)  

3.  [OBJECTIVES](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/documentary/objectives)  

4.  [SECTION](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/documentary/section)  

5.  [step](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/documentary/step)  

6.  [test case](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/documentary/test-case)  

7.  [test objective](/automation-guide/action-based-testing-language/built-in-actions/test-support-actions/documentary/test-objective)  





