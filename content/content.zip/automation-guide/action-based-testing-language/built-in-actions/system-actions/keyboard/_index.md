--- 
title: "Keyboard"
linktitle: "Keyboard"
description: "This category consists of a single built-in action, type, which can simulate the pressing of keys such as Enter, Spacebar, Backspace, all arrow keys, and function keys ( F1, F2, etc.), as well as key combinations."
weight: 7
aliases: 
    - /TA_Automation/Topics/bia_keyboard.html
keywords: 
---

This category consists of a single built-in action, type, which can simulate the pressing of keys such as Enter, Spacebar, Backspace, all arrow keys, and function keys \( F1, F2, etc.\), as well as key combinations.

1.  [hold key](/automation-guide/action-based-testing-language/built-in-actions/system-actions/keyboard/hold-key)  

2.  [release key](/automation-guide/action-based-testing-language/built-in-actions/system-actions/keyboard/release-key)  

3.  [type](/automation-guide/action-based-testing-language/built-in-actions/system-actions/keyboard/type)  





