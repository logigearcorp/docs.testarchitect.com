--- 
title: "JSON"
linktitle: "JSON"
description: "This section contains information on JSON automation."
weight: 6
aliases: 
    - /TA_Automation/Topics/bia_JSON.html
keywords: 
---

This section contains information on JSON automation.

1.  [check json query result](/automation-guide/action-based-testing-language/built-in-actions/system-actions/json/check-json-query-result)  

2.  [get json query result](/automation-guide/action-based-testing-language/built-in-actions/system-actions/json/get-json-query-result)  





