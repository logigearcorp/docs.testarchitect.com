--- 
title: "multi touch tap"
linktitle: "multi touch tap"
description: "Description Mimic concurrent taps in multiple locations within a window or control. Arguments window TA name of the window. control (Optional) TA name of the control, if any. hold duration (Optional) ..."
weight: 19
aliases: 
    - /TA_Automation/Topics/bia_multi_touch_tap.html
keywords: "built-in actions, multi touch tap, multi touch tap (action), iOS (action), multi touch tap, 2 finger tap, tap with 2 fingers., tap with 3 fingers"
---

## Description

Mimic concurrent taps in multiple locations within a window or control.

## Arguments

-   **window**

    TA name of the window.

-   **control**

    \(Optional\) TA name of the control, if any.

-   **hold duration**

    \(Optional\) Duration of touch applied to each of the touch arguments \(units: milliseconds; valid range: 500 to 60,000; defaults to an instantaneous tap\).

-   **touch1, touch2, ... , touchN**

    Touch locations \(format for each: `x, y`; units: points\).


## Valid contexts

This action may be used within the following project items:test modules and user-defined actions.

## Applicable Systems/Platforms {{< permerlink >}} {#bia_multi_touch_tap__section_eqr_2cl_zcb} 

Use of this action is supported on the following systems/platforms: iOS.

## Notes {{< permerlink >}} {#bia_multi_touch_tap__section_tll_j2y_mk} 

-   Built-in UI actions applied to iOS devices specify screen coordinates in points rather than pixels. \(For further details, refer to the built-in action [get screen resolution](/automation-guide/action-based-testing-language/built-in-actions/system-actions/operating-system/get-screen-resolution#li.ios.get_screen_resolution).\)
-   If a value is provided for the control argument, coordinates of the touch arguments relate to the top left corner of the control. If control is blank, the touch arguments relate to the window. For example: to simulate two touches at locations \(20,35\) and \(45, 80\) relative to the window, omit the control argument and set touch1 to 20, 35 and touch2 to 45, 80.
-   This action supports the [<ignore\>](/automation-guide/action-based-testing-language/the-test-language/ignoring-actions) modifier. If the string `<ignore>` is present as the value of any of the arguments, or any argument contains an expression that evaluates to `<ignore>`, the action is skipped during execution.

## Applicable Built-In Settings

The following settings are applicable to this action:[case sensitive](/automation-guide/action-based-testing-language/built-in-settings/value-settings/case-sensitive), [remove double quotes from cells](/automation-guide/action-based-testing-language/built-in-settings/value-settings/remove-double-quotes-from-cells), [standard ASCII only](/automation-guide/action-based-testing-language/built-in-settings/value-settings/standard-ascii-only), [window wait](/automation-guide/action-based-testing-language/built-in-settings/timing-settings/window-wait).

## Applicable Controls

This action is applicable to the following controls:activity indicator view, button, collection view, collection view cell, date picker, image, label, map view, navigation bar, page control, picker view, progress bar, scroll view, search bar, segmented control, slider, stepper, switch, tab bar, table view, table view cell, text view, text box, toolbar, view, web view, window.

## Example

After creating picture checks for all the fruits in this window, tab the apple and orange simultaneously.

![](/images/TA_Automation/Images/bia_multi_touch_tap_aut.r02.png)

Action Lines

The following action lines presume that picture checks have already been created for the various fruit icons.

![](/images/TA_Automation/Images/bia_multi_touch_tap_pgm.r02.png)



