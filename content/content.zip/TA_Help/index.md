--- 
title: "Creating a new system tree"
aliases: 
    - TA_Help/Topics/Variations_create_linked_create_system_tree.html
---
# Creating a new system tree

Creating each category of system node is discussed.

